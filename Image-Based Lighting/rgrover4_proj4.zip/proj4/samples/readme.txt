Directory contents:

empty.jpg              background photo used for inserting objects
{0024,...,0553}.jpg    mirrorball photos used to compute latlon.hdr 
                       (exposure times are 1/24s, ..., 1/553s)
latlon.hdr -           equirectangular HDR map used for relighting
ibl.blend -            example blend file

